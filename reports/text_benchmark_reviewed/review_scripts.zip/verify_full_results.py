"""Independent aggregate checks of saved full-data predictions; no model fitting."""
import json
import hashlib
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, log_loss
sys.path.insert(0,str(Path.cwd()))
from src.benchmark_reporting import load_bundle
from src.programme_audit import file_sha256

folder=Path('reports/text_benchmark_20261102')
bundle=load_bundle(folder,require_review=False)
r=bundle['benchmark']
cache=Path('reports/text_benchmark_private/features.pkl')
meta=json.loads(cache.with_suffix('.metadata.json').read_text())
assert file_sha256(cache)==meta['cache_sha256']
assert meta['identity']==bundle['provenance']['data_and_feature_identity']
assert file_sha256(Path('data/Kiva_Loans.pkl'))==meta['identity']['data_sha256']
frame=pd.read_pickle(cache)
metric_error=0.; interval_error=0.; calibration_mean_error=0.; reviewed_models=0; reviewed_intervals=0; reviewed_slices=0
prediction_hashes={}
for window in r['windows']:
    year=window['year']; cutoff=pd.Timestamp(year=year,month=1,day=1,tz="UTC"); end=pd.Timestamp(year=year+1,month=1,day=1,tz="UTC")
    expected_train=np.flatnonzero((frame.valid_completed_outcome & (frame.fundraisingDate<cutoff) & (frame.raisedDate<cutoff)).to_numpy())
    expected_test=np.flatnonzero((frame.valid_completed_outcome & (frame.fundraisingDate>=cutoff) & (frame.fundraisingDate<end)).to_numpy())
    assert len(expected_train)==window['train_rows'] and len(expected_test)==window['test_rows']
    for name,positions in [('train',expected_train),('test',expected_test)]:
        assert hashlib.sha256(positions.astype('<i8').tobytes()).hexdigest()==window[name+'_row_identity_sha256']
    predpath=folder/'private'/f'predictions-{year}.npz'
    prediction_hashes[str(year)]=file_sha256(predpath)
    saved=np.load(predpath)
    assert np.array_equal(expected_test,saved['row_position'])
    yd=saved['y_days']; yb=saved['y_binary']
    assert np.array_equal(yd,frame.iloc[expected_test].funding_speed_days.to_numpy())
    assert np.array_equal(yb,(yd<=1).astype(int))
    obs=frame.iloc[expected_test]
    groups_by_dim={'month':obs.fundraisingDate.dt.strftime('%Y-%m').to_numpy(),
                   'country':obs.country_iso.to_numpy(),'sector':obs.sector.to_numpy(),
                   'amount_band':obs.loan_size_band.to_numpy(),
                   'description_missing':obs.description_missing.astype(str).to_numpy(),
                   'status':obs.status.astype(str).to_numpy(),
                   'duration_band':np.select([yd<=1,yd<=3,yd<=7,yd<=30],['0–1 days','1–3 days','3–7 days','7–30 days'],default='over 30 days')}
    for field in ['description_signature','template_signature','country_iso']:
        known=set(frame.iloc[expected_train][field])
        groups_by_dim[field+'_novelty']=np.asarray(['missing' if x=='' else ('seen' if x in known else 'unseen') for x in obs[field]])
    masks={(dim,str(group)):values==group for dim,values in groups_by_dim.items() for group in np.unique(values)}
    for m in [m for m in r['models'] if m['year']==year]:
        prefix=m['family']+'__'+m['arm'].replace('+','_')
        d=saved[prefix+'__days'].astype(float); raw_probability=saved[prefix+'__probability']; p=raw_probability.astype(float); error=d-yd
        assert np.isfinite(d).all() and np.isfinite(p).all()
        assert (d>=0).all() and ((p>=0)&(p<=1)).all()
        scores={'rows':len(d),'prevalence':yb.mean(),'mae_days':np.abs(error).mean(),
                'median_ae_days':np.median(np.abs(error)),'rmse_days':np.sqrt(np.mean(error**2)),
                'r2_days':1-np.sum(error**2)/np.sum((yd-yd.mean())**2),'bias_days':error.mean(),
                'log_mae':np.mean(np.abs(np.log1p(d)-np.log1p(yd))),
                'brier':np.mean((p-yb)**2),'roc_auc':roc_auc_score(yb,p),
                'average_precision':average_precision_score(yb,p),'log_loss':log_loss(yb,p)}
        for k,v in scores.items():metric_error=max(metric_error,abs(v-m['metrics'][k]))
        for i,b in enumerate(m['calibration']):
            # Reproduce recorded bin boundaries in the saved prediction dtype.
            mask=np.clip(np.floor(raw_probability*10),0,9)==i
            assert int(mask.sum())==b['count']
            if mask.any():
                calibration_mean_error=max(calibration_mean_error,abs(p[mask].mean()-b['mean_probability']))
                assert abs(p[mask].mean()-b['mean_probability'])<1e-6  # float32 stored means
                assert abs(yb[mask].mean()-b['observed_rate'])<1e-12
        recorded={(item['dimension'],item['group']):item for item in m['slices']}
        assert len(recorded)==len(m['slices']) and set(recorded)==set(masks)
        for key,mask in masks.items():
            item=recorded[key]; n=int(mask.sum())
            assert item['rows']==n
            assert item['suppressed']==(n<r['configuration']['min_slice_rows'])
            if not item['suppressed']:
                for k,v in {'prevalence':yb[mask].mean(),'mae_days':np.abs(error[mask]).mean(),
                            'bias_days':error[mask].mean(),'brier':np.mean((p[mask]-yb[mask])**2)}.items():
                    assert abs(v-item[k])<1e-10
            reviewed_slices+=1
        reviewed_models+=1
    obs=frame.iloc[expected_test]
    for pair in [p for p in r['paired_comparisons'] if p['year']==year]:
        def losses(arm):
            prefix=pair['family']+'__'+arm.replace('+','_')
            return np.abs(saved[prefix+'__days']-yd) if pair['metric']=='mae_days' else (saved[prefix+'__probability']-yb)**2
        gain=losses(pair['baseline'])-losses(pair['candidate'])
        assert abs(gain.mean()-pair['gain'])<1e-12
        groups=obs.fundraisingDate.dt.strftime('%Y-%m').to_numpy() if pair['resampling_unit']=='calendar_month' else obs.country_iso.to_numpy()
        names=np.unique(groups)
        totals=np.array([gain[groups==g].sum() for g in names])
        counts=np.array([(groups==g).sum() for g in names])
        assert len(names)==pair['clusters']
        rng=np.random.default_rng(r['configuration']['seed'])
        boot=[]
        for _ in range(pair['resamples']):
            idx=rng.integers(len(names),size=len(names))
            boot.append(totals[idx].sum()/counts[idx].sum())
        if len(names)>1:
            interval_error=max(interval_error,float(np.max(np.abs(np.quantile(boot,[.025,.975])-pair['interval_95']))))
        else: assert pair['interval_95'] is None
        reviewed_intervals+=1
    print('Verified',year,flush=True)
assert metric_error<1e-10 and interval_error<1e-10
linear=[m for m in r['models'] if m['family']=='linear']
assert all(max(m['fit']['duration_iterations'])<1000 for m in linear)
assert all(m['fit']['classifier_iterations']<100 for m in linear)
out={'status':'passed','models_recomputed':reviewed_models,'paired_intervals_recomputed':reviewed_intervals,'group_slices_recomputed':reviewed_slices,
     'max_metric_absolute_difference':float(metric_error),'max_calibration_mean_difference_float64_reference':float(calibration_mean_error),'max_interval_absolute_difference':interval_error,
     'calendar_splits_and_row_order':'independently checked counts, positions and both hashes against identity-verified private feature frame',
     'feature_cache_and_data_identity':'hashes and metadata verified against benchmark provenance',
     'reliability_bin_counts_and_means':'checked all models',
     'ridge_iteration_max':max(max(m['fit']['duration_iterations']) for m in linear),
     'sgd_iteration_max':max(m['fit']['classifier_iterations'] for m in linear),
     'warning_count':r['model_warning_count'],'private_prediction_archive_sha256':prediction_hashes,
     'benchmark_sha256':bundle['provenance']['benchmark_sha256']}
Path('reports/text_benchmark_private/prediction_review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
