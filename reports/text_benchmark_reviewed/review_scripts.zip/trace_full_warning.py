"""Private diagnostic: refit 2021 text arm and inspect its intercept arithmetic."""
import json
import sys
import warnings
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()))
import src.benchmark_models as models
from src.benchmark_data import calendar_split
from src.benchmark_cache import load_features
from src.programme_audit import file_sha256

original=models.Ridge
checks=[]
class AuditedRidge(original):
    def _set_intercept(self,X_offset,y_offset,X_scale):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            super()._set_intercept(X_offset,y_offset,X_scale)
        reference=float(y_offset)-float(np.sum(np.asarray(X_offset,dtype=np.float64)*np.asarray(self.coef_,dtype=np.float64)))
        difference=reference-float(self.intercept_)
        checks.append({'features':len(self.coef_),'finite_coefficients':bool(np.isfinite(self.coef_).all()),
                       'intercept':float(self.intercept_),'float64_sum_intercept':reference,
                       'log_prediction_difference':difference,
                       'warnings':[{'category':w.category.__name__,'message':str(w.message),
                                    'filename':str(w.filename).split('site-packages/')[-1],'line':w.lineno} for w in caught]})
models.Ridge=AuditedRidge
config=models.default_config()
frame,_,_=load_features(Path('data/Kiva_Loans.pkl'),Path('reports/text_benchmark_private/features.pkl'),config['years'])
train,test=calendar_split(frame,2021)
config['linear_arms']=['T']; config['tree_arms']=[]
saved_path=Path('reports/text_benchmark_20261102/private/predictions-2021.npz')
saved=np.load(saved_path)
comparison={}
for family,arm,pred,meta in models.fit_predict_window(frame,train,test,config):
    if family!='linear':continue
    key=family+'__'+arm
    comparison={name:float(np.max(np.abs(values-saved[key+'__'+name]))) for name,values in pred.items()}
    shift=checks[-1]['log_prediction_difference']
    comparison['max_days_change_intercept_reference_upper_bound']=float(np.max(np.abs(np.expm1(np.log1p(pred['days'])+shift)-pred['days'])))
    comparison['fit_metadata']=meta
out={'diagnostic':'Actual 2021 T refit; full-data core source unchanged',
     'private_prediction_archive_sha256':file_sha256(saved_path),'intercept_checks':checks,
     'repeat_prediction_max_absolute_difference':comparison}
Path('reports/text_benchmark_private/actual_warning_review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
