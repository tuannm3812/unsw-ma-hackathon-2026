"""Small synthetic-only warning reproduction; never loads project loan data.

Run with the project's Python environment. The adjacent JSON is diagnostic
evidence about this environment, not validation of a full-data fitted model.
"""
from __future__ import annotations

import json
import platform
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import scipy
import sklearn
from scipy import sparse
from sklearn.linear_model import Ridge, SGDClassifier
from sklearn.utils.sparsefuncs import mean_variance_axis
from threadpoolctl import threadpool_limits


def capture(operation):
    """Capture warning categories/locations without exporting local paths."""
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result = operation()
    records = []
    for warning in caught:
        filename = Path(warning.filename)
        location = '/'.join(filename.parts[-3:]) if 'sklearn' in filename.parts else filename.name
        records.append({'category': warning.category.__name__,
                        'message': str(warning.message),
                        'source': location, 'line': warning.lineno})
    return result, records


def run():
    result = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Synthetic vectors and 300-row CSR matrices only; no loan data.',
        'boundary': 'This reproduction does not establish the numerical accuracy of the main full-data fit.',
        'environment': {'python': platform.python_version(),
                        'system': platform.system(), 'machine': platform.machine(),
                        'numpy': np.__version__, 'scipy': scipy.__version__,
                        'sklearn': sklearn.__version__,
                        'numpy_blas': np.__config__.CONFIG.get('Build Dependencies', {}).get('blas', {}).get('name')},
        'threads': 1, 'vector_probes': [], 'ridge_probes': [],
    }
    with threadpool_limits(limits=1):
        rng = np.random.default_rng(42)
        for size in [50, 500, 5000, 5500, 10000]:
            left = rng.normal(size=size).astype('float32')
            right = rng.normal(size=size).astype('float32')
            value, caught = capture(lambda: left @ right)
            reference = np.sum(left.astype('float64') * right.astype('float64'))
            result['vector_probes'].append({
                'size': size, 'dtype': 'float32', 'warnings': caught,
                'matmul': float(value), 'float64_product_sum': float(reference),
                'absolute_difference': float(abs(value - reference)),
                'finite': bool(np.isfinite(value)),
            })
        for seed in [0, 1, 42]:
            for features in [5000, 5500]:
                rng = np.random.default_rng(seed)
                matrix = sparse.random(300, features, density=.02, random_state=seed,
                                       dtype=np.float32, format='csr')
                target = rng.normal(size=300)
                params = {'alpha': 10, 'solver': 'lsqr', 'tol': 1e-5, 'max_iter': 1000}
                fitted, caught = capture(lambda: Ridge(**params).fit(matrix, target))
                double, double_warnings = capture(
                    lambda: Ridge(**params).fit(matrix.astype('float64'), target))
                offset, _ = mean_variance_axis(matrix, axis=0)
                reference = float(target.astype('float32').mean()) - np.sum(
                    offset.astype('float64') * fitted.coef_.astype('float64'))
                prediction = fitted.predict(matrix)
                corrected = matrix @ fitted.coef_ + reference
                sgd, sgd_warnings = capture(lambda: SGDClassifier(
                    loss='log_loss', alpha=1e-5, max_iter=100, tol=1e-4,
                    average=True, random_state=42).fit(matrix, target > 0))
                result['ridge_probes'].append({
                    'seed': seed, 'shape': list(matrix.shape), 'nonzero': matrix.nnz,
                    'configuration': params, 'float32_warnings': caught,
                    'float64_warnings': double_warnings, 'sgd_warnings': sgd_warnings,
                    'coefficients_finite': bool(np.isfinite(fitted.coef_).all()),
                    'sgd_coefficients_finite': bool(np.isfinite(sgd.coef_).all()),
                    'predictions_finite': bool(np.isfinite(prediction).all()),
                    'float32_intercept': float(fitted.intercept_),
                    'float64_sum_reference_intercept': float(reference),
                    'absolute_intercept_difference': float(abs(fitted.intercept_ - reference)),
                    'maximum_prediction_difference_after_intercept_correction': float(np.max(np.abs(prediction - corrected))),
                    'maximum_prediction_difference_to_float64_fit': float(np.max(np.abs(prediction - double.predict(matrix)))),
                    'iterations': fitted.n_iter_.tolist(),
                })
    return result


if __name__ == '__main__':
    destination = Path(__file__).with_suffix('.json')
    result = run()
    destination.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'artifact': destination.name,
                      'vector_probes': len(result['vector_probes']),
                      'ridge_probes': len(result['ridge_probes'])}))
